class FileManager:
    def __init__(self,file_name):
        self.file_name=file_name
    def read_file(self):
        tmp = open(self.file_name, "r")   
        print(tmp.read())
        tmp.close()
    def update_file(self,text_data):
        self.text_data=text_data 
        tmp = open(self.file_name, "a")   
        tmp.write(text_data)
        tmp.close()
     